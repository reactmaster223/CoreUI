import React from 'react'

const Dashboard = () => {
  return <>Hello World!</>
}

export default Dashboard

/* global coreui */

/**
 * --------------------------------------------------------------------------
 * CoreUI Boostrap Admin Template (v4.1.1): popovers.js
 * License (https://coreui.io/pro/license)
 * --------------------------------------------------------------------------
 */

document.querySelectorAll('[data-coreui-toggle="popover"]').forEach(element => {
  // eslint-disable-next-line no-new
  new coreui.Popover(element)
})


<template>
  <CDropdown 
    placement="bottom-end"
    :caret="false"
    in-nav
    class="c-header-nav-item mx-2"
    add-menu-classes="pt-0"
  >
    <template #toggler>
      <CHeaderNavItem only-link>
        <CIcon name="bell"/>
        <CBadge pill color="danger">{{itemsCount}}</CBadge>
      </CHeaderNavItem>
    </template>
    <CDropdownHeader 
      tag="div" 
      class="text-center bg-light"
    >
      <strong>You have {{itemsCount}} notifications</strong>
    </CDropdownHeader>
    <CDropdownItem>
      <i class="cui-user-follow text-success mr-2"></i> New user registered
    </CDropdownItem>
    <CDropdownItem>
      <i class="cui-user-unfollow text-danger mr-2"></i> User deleted
    </CDropdownItem>
    <CDropdownItem>
      <i class="cui-chart text-info mr-2"></i> Sales report is ready
    </CDropdownItem>
    <CDropdownItem>
      <i class="cui-basket-loaded text-primary mr-2"></i> New client
    </CDropdownItem>
    <CDropdownItem>
      <i class="cui-speedometer text-warning mr-2"></i> Server overloaded
      </CDropdownItem>
    <CDropdownHeader tag="div" class="text-center bg-light">
      <strong>Server</strong>
    </CDropdownHeader>
    <CDropdownItem class="d-block">
      <div class="text-uppercase mb-1">
        <small><b>CPU Usage</b></small>
      </div>
      <CProgress class="progress-xs" color="info" :value="25"/>
      <small class="text-muted">348 Processes. 1/4 Cores.</small>
    </CDropdownItem>
    <CDropdownItem class="d-block">
      <div class="text-uppercase mb-1">
        <small><b>Memory Usage</b></small>
      </div>
      <CProgress class="progress-xs" color="warning" :value="70"/>
      <small class="text-muted">11444GB/16384MB</small>
    </CDropdownItem>
    <CDropdownItem class="d-block">
      <div class="text-uppercase mb-1">
        <small><b>SSD 1 Usage</b></small>
      </div>
      <CProgress class="progress-xs" color="danger" :value="90"/>
      <small class="text-muted">243GB/256GB</small>
    </CDropdownItem>
  </CDropdown>
</template>
<script>
export default {
  name: 'TheHeaderDropdownNotif',
  data () {
    return { itemsCount: 5 }
  }
}
</script>

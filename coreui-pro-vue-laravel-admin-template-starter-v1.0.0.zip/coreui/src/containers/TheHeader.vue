<template>
  <CHeader with-subheader>
    <CHeaderBrand
      class="mx-auto d-lg-none" 
      src="img/brand/coreui-base.svg"
      width="97"
      height="46"
      alt="CoreUI Logo"
      :wrappedInLink="{ href: 'https://coreui.io', target: '_blank'}"
    />
    <CHeaderNav class="d-md-down-none mr-auto">
      <CHeaderNavItem class="px-3">
        <CHeaderNavLink
          href="#/dashboard"
        >
          Dashboard
        </CHeaderNavLink>
      </CHeaderNavItem>
      <CHeaderNavItem class="px-3">
        <CHeaderNavLink
          href="#/users"
        >
          Users
        </CHeaderNavLink>
      </CHeaderNavItem>
      <CHeaderNavItem>
        <CHeaderNavLink>
          <div @click="logout()">
            Logout
          </div>
        </CHeaderNavLink>
      </CHeaderNavItem>
    </CHeaderNav>
    <CHeaderNav>

    </CHeaderNav>
 
    <CSubheader class="px-3">
      <CBreadcrumbRouter class="border-0"/>
    </CSubheader>
  </CHeader>
</template>

<script>
import axios from 'axios'

export default {
  name: 'TheHeader',
  components: {
  },
  computed: {
    logoClasses () {
      return [
        'c-header-brand',
        { 'c-header-brand-minimized': this.sidebarIsMinimized }
      ]
    }
  },
  methods:{
    logout(){
      let self = this;
      axios.post('/api/logout?token=' + localStorage.getItem("api_token"),{})
      .then(function (response) {
        self.$router.push({ path: '/login' });
      }).catch(function (error) {
        console.log(error); 
      });
    }
  },
  mounted () {

  }
}
</script>
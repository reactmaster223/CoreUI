<template>
  <div>
    <CCard>
      <CCardBody>
        <CRow>
          <h3>DASHBOARD</h3>
        </CRow>
      </CCardBody>
    </CCard>
  </div>
</template>

<script>

</script>

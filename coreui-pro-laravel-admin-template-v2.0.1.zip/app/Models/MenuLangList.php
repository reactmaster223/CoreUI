<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MenuLangList extends Model
{
    protected $table = 'menu_lang_lists';
    public $timestamps = false; 
}

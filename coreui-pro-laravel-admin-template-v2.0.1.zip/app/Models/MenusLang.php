<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MenusLang extends Model
{
    protected $table = 'menus_lang';
    public $timestamps = false; 
}

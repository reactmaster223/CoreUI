@extends('dashboard.base')

@section('css')
    <link href="{{ asset('css/codemirror.css') }}" rel="stylesheet">
@endsection

@section('content')

<div class="container-fluid">
            <div class="animated fade-in">
              <div class="card">
                <div class="card-header">
                  Code Editor - CodeMirror
                  <a href="https://coreui.io/pro/" class="badge badge-danger">CoreUI Pro Component</a>
                  <div class="card-header-actions">
                    <a href="http://codemirror.net" class="card-header-action" target="_blank"><small class="text-muted">docs</small></a>
                  </div>
                </div>
                <!-- Create code editor container -->
                <textarea id="codemirror">
  <!DOCTYPE html>
  <html lang="en">
  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Łukasz Holeczek">
    <meta name="keyword" content="">
    <link rel="shortcut icon" href="img/favicon.png">

    <title></title>

    <!-- Icons -->
    <link href="node_modules/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="node_modules/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">

    <!-- Main styles for this application -->
    <link href="css/style.css" rel="stylesheet">

  </head>


<body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
  <header class="header navbar">
    ...
  </header>
  <div class="app-body">
    <div class="sidebar">
      ...
    </div>
    <!-- Main content -->
    <main class="main">

    </main>
    <aside class="aside-menu">
      ...
    </aside>
  </div>
  <footer class="footer">
    ...
  </footer>

  <!-- Bootstrap and necessary plugins -->
  <script src="node_modules/jquery/dist/jquery.min.js"></script>
  <script src="node_modules/popper.js/dist/umd/popper.min.js"></script>
  <script src="node_modules/pace-progress/pace.min.js"></script>

  <!-- Plugins and scripts required by all views -->
  <script src="node_modules/chart.js/dist/Chart.min.js"></script>

  <!-- Main scripts -->
  <script src="js/app-config.js"></script>
  <script src="js/app.js"></script>

</body>
</html>
    </textarea>
              </div>
            </div>

          </div>

@endsection

@section('javascript')
    <script src="{{ asset('js/codemirror.js') }}"></script>
    <script src="{{ asset('js/xml.js') }}"></script>
    <script src="{{ asset('js/code-editor.js') }}"></script>
@endsection
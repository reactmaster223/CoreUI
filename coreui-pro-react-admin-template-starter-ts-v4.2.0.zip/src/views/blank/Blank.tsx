import React from 'react'

const Blank = (): JSX.Element => {
  return <></>
}

export default Blank

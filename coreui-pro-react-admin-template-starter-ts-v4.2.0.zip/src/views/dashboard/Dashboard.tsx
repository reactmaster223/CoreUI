import React from 'react'

const Dashboard = (): JSX.Element => {
  return <>Hello World!</>
}

export default Dashboard

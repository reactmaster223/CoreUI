module.exports = {
  semi: false,
  trailingComma: "all",
  singleQuote: true,
  tabWidth: 2
};

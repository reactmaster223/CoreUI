@extends('coreui.base')

@section('css')

@endsection

@section('content')

<h3>DASHBOARD</h3>

@endsection

@section('javascript')

@endsection

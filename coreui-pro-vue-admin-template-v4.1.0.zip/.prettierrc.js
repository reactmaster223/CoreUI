module.exports = {
  // jsxBracketSameLine: true,
  semi: false,
  trailingComma: "all",
  singleQuote: true,
  tabWidth: 2
};

import { NgModule } from '@angular/core';
import { ChartjsComponent } from './chartjs.component';

@NgModule({
  declarations: [
    ChartjsComponent
  ],
  exports: [
    ChartjsComponent
  ]
})
export class ChartjsModule { }

import { NavbarTogglerDirective } from './navbar-toggler.directive';

describe('NavbarTogglerDirective', () => {
  it('should create an instance', () => {
    // const directive = new NavbarTogglerDirective();
    // expect(directive).toBeTruthy();
  });
});

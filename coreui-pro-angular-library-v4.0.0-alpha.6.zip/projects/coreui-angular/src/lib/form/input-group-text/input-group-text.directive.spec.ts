import { InputGroupTextDirective } from './input-group-text.directive';

describe('InputGroupTextDirective', () => {
  it('should create an instance', () => {
    const directive = new InputGroupTextDirective();
    expect(directive).toBeTruthy();
  });
});

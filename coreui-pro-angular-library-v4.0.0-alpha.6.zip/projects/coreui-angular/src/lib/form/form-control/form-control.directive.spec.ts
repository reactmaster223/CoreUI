import { FormControlDirective } from './form-control.directive';

describe('FormControlDirective', () => {
  it('should create an instance', () => {
    // const directive = new FormControlDirective();
    // expect(directive).toBeTruthy();
  });
});

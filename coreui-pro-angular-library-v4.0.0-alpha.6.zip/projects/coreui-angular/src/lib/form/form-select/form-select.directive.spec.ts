import { FormSelectDirective } from './form-select.directive';

describe('FormSelectDirective', () => {
  it('should create an instance', () => {
    const directive = new FormSelectDirective();
    expect(directive).toBeTruthy();
  });
});

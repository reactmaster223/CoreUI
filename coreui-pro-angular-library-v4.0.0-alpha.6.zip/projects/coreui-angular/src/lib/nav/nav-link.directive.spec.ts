import { NavLinkDirective } from './nav-link.directive';

describe('NavLinkDirective', () => {
  it('should create an instance', () => {
    const directive = new NavLinkDirective();
    expect(directive).toBeTruthy();
  });
});

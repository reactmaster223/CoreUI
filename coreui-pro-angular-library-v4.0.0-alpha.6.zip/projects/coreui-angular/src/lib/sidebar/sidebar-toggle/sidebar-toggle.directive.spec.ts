import { SidebarToggleDirective } from './sidebar-toggle.directive';

describe('SidebarToggleDirective', () => {
  it('should create an instance', () => {
    // todo
    // const directive = new SidebarToggleDirective();
    // expect(directive).toBeTruthy();
  });
});

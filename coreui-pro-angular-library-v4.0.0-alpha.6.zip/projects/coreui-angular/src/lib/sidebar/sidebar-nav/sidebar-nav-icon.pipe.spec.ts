import { SidebarNavIconPipe } from './sidebar-nav-icon.pipe';

describe('SidebarNavIconPipe', () => {
  it('create an instance', () => {
    const pipe = new SidebarNavIconPipe();
    expect(pipe).toBeTruthy();
  });
});

import { SidebarNavBadgePipe } from './sidebar-nav-badge.pipe';

describe('SidebarNavBadgePipe', () => {
  it('create an instance', () => {
    const pipe = new SidebarNavBadgePipe();
    expect(pipe).toBeTruthy();
  });
});

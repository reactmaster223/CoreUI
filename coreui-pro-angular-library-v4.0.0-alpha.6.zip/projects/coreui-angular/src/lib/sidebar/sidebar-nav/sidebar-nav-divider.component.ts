import { Component, Input } from '@angular/core';

@Component({
  selector: 'c-sidebar-nav-divider',
  template: ``
})
export class SidebarNavDividerComponent {
  @Input() item: any;

  constructor() {
  }

}

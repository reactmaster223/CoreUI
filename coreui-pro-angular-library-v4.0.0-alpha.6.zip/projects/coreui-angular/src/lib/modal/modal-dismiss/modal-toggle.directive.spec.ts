import { ModalToggleDirective } from './modal-toggle.directive';

describe('ModalToggleDirective', () => {
  // it('should create an instance', () => {
  //   const directive = new ModalDismissDirective();
  //   expect(directive).toBeTruthy();
  // });
});

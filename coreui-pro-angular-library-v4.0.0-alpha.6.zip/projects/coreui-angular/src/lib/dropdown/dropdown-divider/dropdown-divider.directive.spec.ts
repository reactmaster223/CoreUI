import { DropdownDividerDirective } from './dropdown-divider.directive';

describe('DropdownDividerDirective', () => {
  it('should create an instance', () => {
    const directive = new DropdownDividerDirective();
    expect(directive).toBeTruthy();
  });
});

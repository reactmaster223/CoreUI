import { DropdownItemDirective } from './dropdown-item.directive';

describe('DropdownItemDirective', () => {
  // it('should create an instance', () => {
  //   const directive = new DropdownItemDirective();
  //   expect(directive).toBeTruthy();
  // });
});

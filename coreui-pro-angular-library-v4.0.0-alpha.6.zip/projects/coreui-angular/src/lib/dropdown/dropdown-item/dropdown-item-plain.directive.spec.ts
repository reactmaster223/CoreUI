import { DropdownItemPlainDirective } from './dropdown-item-plain.directive';

describe('DropdownItemPlainDirective', () => {
  it('should create an instance', () => {
    const directive = new DropdownItemPlainDirective();
    expect(directive).toBeTruthy();
  });
});

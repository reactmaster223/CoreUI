import { DropdownMenuDirective } from './dropdown-menu.directive';

describe('DropdownMenuDirective', () => {
  // it('should create an instance', () => {
  //   const directive = new DropdownMenuDirective();
  //   expect(directive).toBeTruthy();
  // });
});

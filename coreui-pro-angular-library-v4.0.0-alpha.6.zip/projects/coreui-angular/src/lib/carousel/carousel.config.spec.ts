import { CarouselConfig } from './carousel.config';

describe('CarouselConfig', () => {
  it('should create an instance', () => {
    expect(new CarouselConfig()).toBeTruthy();
  });
});

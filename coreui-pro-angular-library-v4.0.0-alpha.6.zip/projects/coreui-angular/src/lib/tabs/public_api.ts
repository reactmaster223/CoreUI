export { TabPaneComponent } from './tab-pane/tab-pane.component';
export { TabContentComponent } from './tab-content/tab-content.component';
export { TabContentRefDirective } from './tab-content-ref.directive';
export { TabService } from './tab.service';
export { TabsModule } from './tabs.module';

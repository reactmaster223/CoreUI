import { HeaderTogglerDirective } from './header-toggler.directive';

describe('HeaderTogglerDirective', () => {
  it('should create an instance', () => {
    // todo
    // const directive = new HeaderTogglerDirective();
    // expect(directive).toBeTruthy();
  });
});

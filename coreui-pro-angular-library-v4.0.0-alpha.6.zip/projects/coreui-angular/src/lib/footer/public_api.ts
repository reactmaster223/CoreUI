export { FooterComponent } from './footer.component';
export { FooterModule } from './footer.module';

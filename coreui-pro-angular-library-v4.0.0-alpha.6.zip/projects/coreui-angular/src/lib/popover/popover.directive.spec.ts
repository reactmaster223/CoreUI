import { PopoverDirective } from './popover.directive';

describe('PopoverDirective', () => {
  // it('should create an instance', () => {
  //   const directive = new PopoverDirective();
  //   expect(directive).toBeTruthy();
  // });
});

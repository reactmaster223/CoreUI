export { ImgDirective } from './img.directive';
export { ImgModule } from './img.module';

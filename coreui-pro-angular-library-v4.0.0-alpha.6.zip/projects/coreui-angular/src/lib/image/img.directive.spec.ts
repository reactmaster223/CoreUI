import { ImgDirective } from './img.directive';

describe('ImgDirective', () => {
  it('should create an instance', () => {
    const directive = new ImgDirective();
    expect(directive).toBeTruthy();
  });
});

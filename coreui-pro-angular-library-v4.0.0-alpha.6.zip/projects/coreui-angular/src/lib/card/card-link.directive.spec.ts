import { CardLinkDirective } from './card-link.directive';

describe('CardLinkDirective', () => {
  it('should create an instance', () => {
    const directive = new CardLinkDirective();
    expect(directive).toBeTruthy();
  });
});

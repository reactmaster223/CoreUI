import { CardImgDirective } from './card-img.directive';

describe('CardImgDirective', () => {
  it('should create an instance', () => {
    const directive = new CardImgDirective();
    expect(directive).toBeTruthy();
  });
});

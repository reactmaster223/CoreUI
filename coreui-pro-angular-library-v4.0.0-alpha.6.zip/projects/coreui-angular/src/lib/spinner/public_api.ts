export { SpinnerComponent } from './spinner.component';
export { SpinnerModule } from './spinner.module';

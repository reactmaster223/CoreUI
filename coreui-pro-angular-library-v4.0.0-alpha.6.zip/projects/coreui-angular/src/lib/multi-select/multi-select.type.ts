import { EventEmitter } from '@angular/core';

export interface IMultiSelect {
  cleaner?: boolean;
  multiple?: boolean;
  options?: any[];
  optionsMaxHeight?: (number | string | 'auto');
  optionsStyle?: (string | 'checkbox' | 'text');
  placeholder?: string;
  search?: boolean;
  searchNoResultsLabel?: string;
  selectAll?: boolean;
  selectAllLabel?: string;
  selectionType?: ('counter' | 'tags' | 'text');
  selectionTypeCounterText?: string;
  visible?: boolean;
  visibleChange?: EventEmitter<boolean>;
}

export type TOptions = IOption[];

export interface IOption {
  disabled?: boolean;
  label?: string;
  options?: TOptions;
  order?: number;
  selected?: boolean;
  text?: string;
  value?: number | string;
}

export interface IMultiSelectOptions {
  handleOptionClick?: (option: IOption) => void;
  options?: IOption[];
  optionsMaxHeight?: number | string;
  optionsStyle?: 'checkbox' | 'text';
  searchNoResultsLabel?: string;
}

import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class MultiSelectService {
  constructor() {}

  private multiSelectState = new BehaviorSubject<any>({});
  multiSelectState$ = this.multiSelectState.asObservable();

  private multiSelectVisible = new BehaviorSubject<boolean>(false);
  multiSelectVisible$ = this.multiSelectVisible.asObservable();

  toggleOption(option: any): void {
    this.multiSelectState.next(option);
  }

  toggleVisible(visible: boolean): void {
    this.multiSelectVisible.next(visible);
  }
}


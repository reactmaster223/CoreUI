import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { A11yModule } from '@angular/cdk/a11y';

import { ButtonModule } from '../button';

import { MultiSelectService } from './multi-select.service';
import { MultiSelectComponent } from './multi-select/multi-select.component';
import { MultiSelectOptionComponent } from './multi-select-option/multi-select-option.component';
import { MultiSelectTagComponent } from './multi-select-tag/multi-select-tag.component';
import { MultiSelectOptgroupComponent } from './multi-select-optgroup/multi-select-optgroup.component';
import { MultiSelectOptgroupLabelComponent } from './multi-select-optgroup/multi-select-optgroup-label.component';
import { MultiSelectNativeSelectComponent } from './multi-select-native-select/multi-select-native-select.component';

@NgModule({
  declarations: [
    MultiSelectComponent,
    MultiSelectOptionComponent,
    MultiSelectOptgroupComponent,
    MultiSelectOptgroupLabelComponent,
    MultiSelectTagComponent,
    MultiSelectNativeSelectComponent
  ],
  imports: [CommonModule, A11yModule, ButtonModule, FormsModule],
  exports: [
    MultiSelectComponent,
    MultiSelectOptionComponent,
    MultiSelectOptgroupComponent,
    MultiSelectOptgroupLabelComponent,
    MultiSelectTagComponent
  ],
  providers: [MultiSelectService]
})
export class MultiSelectModule {
}

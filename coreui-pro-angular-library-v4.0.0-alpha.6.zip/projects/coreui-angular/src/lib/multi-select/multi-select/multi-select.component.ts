import {
  AfterContentInit,
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ContentChildren,
  ElementRef,
  EventEmitter,
  forwardRef,
  HostBinding,
  HostListener,
  Input,
  NgZone,
  OnDestroy,
  OnInit,
  Output,
  QueryList,
  Renderer2,
  ViewChild,
  ViewContainerRef
} from '@angular/core';
import { FocusKeyManager, FocusMonitor, FocusOrigin } from '@angular/cdk/a11y';
import { BooleanInput, coerceBooleanProperty } from '@angular/cdk/coercion';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Subscription } from 'rxjs';

// import { ListenersService } from '../../services/listeners.service';
import { IMultiSelect, IOption } from '../multi-select.type';
import { MultiSelectService } from '../multi-select.service';
import { MultiSelectOptionComponent } from '../multi-select-option/multi-select-option.component';
import { MultiSelectNativeSelectComponent } from '../multi-select-native-select/multi-select-native-select.component';

// const flattenArray = (options: IOption[]): IOption[] => {
//   return options.reduce((acc: IOption[], val: IOption) => {
//     return acc.concat(Array.isArray(val.options) ? flattenArray(val.options) : val);
//   }, []);
// };
//
// const getSelectedOptions = (options: IOption[]) => {
//   return flattenArray(options).filter((option: IOption) => {
//     if (option.selected) {
//       return option;
//     }
//     return;
//   });
// };

interface IPluralMap {
  [k: string]: string;
}

@Component({
  selector: 'c-multi-select',
  templateUrl: './multi-select.component.html',
  styleUrls: ['./multi-select.component.scss'],
  exportAs: 'cMultiSelect',
  providers: [
    MultiSelectService,
    // ListenersService,
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => MultiSelectComponent),
      multi: true
    }
  ]
})
export class MultiSelectComponent
  implements IMultiSelect, ControlValueAccessor, AfterContentInit, AfterViewInit, OnDestroy, OnInit {

  constructor(
    private elementRef: ElementRef,
    private renderer: Renderer2,
    private ngZone: NgZone,
    private changeDetectorRef: ChangeDetectorRef,
    private viewContainerRef: ViewContainerRef,
    private focusMonitor: FocusMonitor,
    private multiSelectService: MultiSelectService
    // private listenersService: ListenersService
  ) {}

  static ngAcceptInputType_multiple: BooleanInput;
  static ngAcceptInputType_disabled: BooleanInput;

  onChange: any = (value: any) => {};

  writeValue(value: (string | string[])): void {
    if (value !== null) {
      this.value = value;
    }
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
  }

  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }

  @Input() cleaner = true;

  @Input()
  set disabled(value: boolean) {
    this._disabled = coerceBooleanProperty(value);
  }
  get disabled(): boolean {
    return this._disabled;
  }
  private _disabled = false;

  @Input()
  set multiple(value: boolean) {
    this._multiple = coerceBooleanProperty(value);
  }
  get multiple(): boolean {
    return this._multiple;
  }
  private _multiple = false;

  @Input() nativeName = '';
  @Input() nativeId = '';
  // @Input() options = [];
  @Input() optionsMaxHeight = 'auto';
  @Input() optionsStyle: 'checkbox' | 'text' = 'checkbox';
  @Input() placeholder = 'Select...';
  @Input() search = true;
  @Input() searchNoResultsLabel = 'no items';
  @Input() selectAll = true;
  @Input() selectAllLabel = 'Select all options';
  @Input() selectionType: 'counter' | 'tags' | 'text' = 'tags';
  @Input() selectionTypeCounterText: string = 'item(s) selected';
  @Input() selectionTypeCounterTextPluralMap?: IPluralMap = { '=1': 'item selected', 'other': 'items selected' };

  @Input()
  set value(value: string | string[]) {
    const newValue = Array.isArray(value) ? [...value] : [value ?? ''];
    if (this._value.toString() !== newValue.toString()) {
      this._value = newValue;
      this.onChange(newValue);
      this.updateNativeSelect();
      this.valueChange.emit(this.value);
    }
  }
  get value() {
    return this.multiple ? [...this._value] : this._value[0]?.toString() ?? '';
  }
  private _value: string[] = [''];

  @Output() readonly valueChange = new EventEmitter<string | string[]>();

  @Input()
  set visible(value: boolean) {
    const newValue = coerceBooleanProperty(value);
    if (newValue !== this._visible) {
      this._visible = newValue;
      this.multiSelectService.toggleVisible(newValue);
      if (newValue) {
        this.listKeyManager.setFirstItemActive();
      }
    }
  }
  get visible() {
    return this._visible;
  }
  private _visible = false;

  @Output() readonly visibleChange = new EventEmitter<boolean>();

  isDropdownVisible = false;

  set selectedOptions(value) {
    this._selectedOptions = value;
    this.value = this.selectedOptions.map(item => item.value);
    this.inputElementSize();
  }
  get selectedOptions() {
    return this._selectedOptions;
  }
  private _selectedOptions: any[] = [];

  get selectedOptionsText() {
    return this.selectedOptions.map((option) => option.label).join(', ');
  }

  get counterText() {
    return `${this.selectedOptions.length} ${this.selectionTypeCounterText}`;
  }

  get counterTextType(): string {
    return typeof this.selectionTypeCounterTextPluralMap ?? typeof this.selectionTypeCounterText;
  };

  private multiselectStateSubscription!: Subscription;
  private multiselectVisibleSubscription!: Subscription;
  private multiSelectOptionsSubscription!: Subscription;
  private focusMonitorSubscription!: Subscription;

  @ContentChildren(MultiSelectOptionComponent, { descendants: true }) multiSelectOptions!: QueryList<MultiSelectOptionComponent>;

  private listKeyManager!: FocusKeyManager<MultiSelectOptionComponent>;

  @ViewChild('inputElement') inputElement!: ElementRef;
  @ViewChild('dropdownElement') dropdownElement!: ElementRef;

  @HostBinding('class') get hostClasses() {
    return {
      'form-multi-select': true,
      'form-multi-select-selection-tags': this.selectionType === 'tags',
      show: this.visible,
      disabled: this.disabled
    };
  }

  @HostBinding('attr.tabindex')
  private get tabIndex() {
    return this._tabIndex;
  }
  private set tabIndex(value) {
    setTimeout(() => {
      this._tabIndex = this.disabled || this.search ? '-1' : value === null ? null : '0';
    });
  }
  private _tabIndex: string | null = '-1';

  @HostListener('keyup', ['$event']) onKeyUp($event: KeyboardEvent): void {
    if (this.disabled) return;

    if ($event.key === 'Escape') {
      this.visible = false;
      this.searchValue = '';
      this.setFocus();
      return;
    }
    if (['Enter', ' ', 'ArrowDown'].includes($event.key) && [this.inputElement?.nativeElement ?? this.elementRef.nativeElement].includes($event.target)) {
      this.visible = true;
      if (!this.search) {
        this.setFocus();
      }
      return;
    }
    if ($event.key === 'Tab' && $event.target === this.elementRef.nativeElement) {
      this.visible = true;
      if (!this.search) {
        this.setFocus();
      }
      return;
    }
  }

  @HostListener('keydown', ['$event']) onKeyDown($event: KeyboardEvent) {
    if (this.disabled) return;
    this.listKeyManager.onKeydown($event);
  }

  @HostListener('click', ['$event']) onClick($event: MouseEvent): void {
    if (this.disabled) return;
    if (!this.visible) {
      this.visible = true;
    }
  }

  public visibleOptions = 0;

  set searchValue(value) {
    this._searchValue = value.trim();
    this.visible = !!this.searchValue.length || this.visible;
    this.filterOptions(this.searchValue);
    this.inputElementSize();
  }
  get searchValue() {
    return this._searchValue;
  }
  private _searchValue: string = '';

  get subtreeFocused() {
    return this._subtreeFocused;
  }
  set subtreeFocused(value: boolean) {
    this._subtreeFocused = this.disabled ? false : value;
    this.visible = value === false ? false : this.visible;
  }
  private _subtreeFocused = this.focusOrigin(null);

  private nativeSelectRef!: any;

  focusOrigin(origin: FocusOrigin): boolean {
    const focused = !!origin;
    this.searchValue = focused ? this.searchValue : '';
    return focused;
  }

  ngOnInit(): void {
    this.tabIndex = '0';
  }

  ngOnDestroy(): void {
    this.multiselectSubscribe(false);
    // this.clearListeners();
    this.focusMonitor.stopMonitoring(this.elementRef);
    this.focusMonitorSubscription?.unsubscribe();
  }

  ngAfterContentInit(): void {
    this.visibleOptions = this.multiSelectOptions.length;
    this.multiSelectOptions.forEach((option, index) => {
      option.optionsStyle = this.optionsStyle;
      option.selected = option.value !== undefined ? this.value.includes(option.value) || option.selected : option.selected;
    });
    this.selectedOptionsUpdate();
    this.inputElementSize();

    this.listKeyManager = new FocusKeyManager(this.multiSelectOptions).withHomeAndEnd().withTypeAhead();
    this.listKeyManager.skipPredicate(item => (!item.visible || item.disabled));
    this.listKeyManager.setFirstItemActive();
    this.multiselectSubscribe();
    this.createNativeSelect();
  }

  ngAfterViewInit(): void {
    // this.setListeners();
    this.focusMonitorSubscription = this.focusMonitor.monitor(this.elementRef, true).subscribe((origin) =>
      this.ngZone.run(() => {
        if (!this.disabled) {
          this.subtreeFocused = this.focusOrigin(origin);
          this.changeDetectorRef.markForCheck();
        }
      })
    );
    this.inputElementSize();
  }

  private multiselectSubscribe(subscribe: boolean = true) {
    if (subscribe) {
      this.multiselectVisibleSubscription = this.multiSelectService.multiSelectVisible$.subscribe(
        (visible) => {
          this.isDropdownVisible = visible;
          this.visibleChange.emit(visible);
        }
      );

      this.multiselectStateSubscription = this.multiSelectService.multiSelectState$.subscribe(
        (option) => {
          if (option.selected === true && !this.multiple) {
            const selectedOptions = this.multiSelectOptions.toArray().filter((item) => item.selected);
            selectedOptions.reverse().forEach((item) => {
              if (item !== option) {
                item.selected = false;
              }
            });
          }
          this.selectedOptionsUpdate();
        }
      );
    } else {
      this.multiselectVisibleSubscription?.unsubscribe();
      this.multiSelectOptionsSubscription?.unsubscribe();
      this.multiselectStateSubscription?.unsubscribe();
    }
  }

  clearAllOptions($event: MouseEvent) {
    this.selectedOptions.forEach((option) => {
      if (!option._disabled) option.selected = false;
    });
    this.setFocus();
  }

  selectAllOptions() {
    this.multiSelectOptions.forEach((option, index) => {
      if (!option.disabled) option.selected = true;
    });
  }

  // private setListeners() {
  //   if (this.search) {
  //     const configForInput: IListenersConfig = {
  //       hostElement: this.inputElement ?? this.elementRef,
  //       trigger: ['focus', 'click'],
  //       callbackOn: () => {
  //         console.log('focus input');
  //         this.tabIndex = null;
  //         // this.visible = true;
  //       }
  //     };
  //     this.listenersService.setListeners(configForInput);
  //   }
  //
  //   const configForHost: IListenersConfig = {
  //     hostElement: this.elementRef,
  //     trigger: ['focus'],
  //     callbackOn: () => {
  //       console.log('focus');
  //       if (this.inputElement) {
  //         this.setFocus()
  //       }
  //       // this.inputElement?.nativeElement.focus();
  //     },
  //     callbackOff: () => {
  //       console.log('blur');
  //     }
  //   };
  //   this.listenersService.setListeners(configForHost);
  // }

  // private clearListeners() {
  //   this.listenersService.clearListeners();
  // }

  handleTagRemove($event: IOption) {
    this.setFocus();
  }

  setFocus() {
    if (this.disabled) return;
    this.focusMonitor.focusVia(this.inputElement ?? this.elementRef, 'program');
  }

  // setFirstSelectedOptionActive() {
  //   const firstSelectedOption = this.selectedOptions.find((item) => item.selected) ??
  //     this.multiSelectOptions.find((item, index) => index === 0);
  //   if (firstSelectedOption && this.isDropdownVisible) {
  //     // this.listKeyManager.setFocusOrigin('keyboard');
  //     this.listKeyManager.setActiveItem(firstSelectedOption);
  //     this.changeDetectorRef.markForCheck();
  //   } else {
  //     // this.listKeyManager.setFocusOrigin('keyboard');
  //     this.listKeyManager.setFirstItemActive();
  //     this.changeDetectorRef.markForCheck();
  //   }
  // }

  filterOptions(value: string) {
    const searchString = value.toLowerCase() ?? '';
    this.multiSelectOptions?.forEach((item, index) => {
      if (!!searchString) {
        item.visible = item.label?.toLowerCase().includes(searchString) ?? true;
      } else {
        item.visible = true;
      }
    });
    this.visibleOptions = this.multiSelectOptions?.filter((item) => item.visible).length;
  }

  createNativeSelect() {
    this.viewContainerRef.clear();
    this.nativeSelectRef = this.viewContainerRef.createComponent(MultiSelectNativeSelectComponent);
    this.updateNativeSelect();
  }

  updateNativeSelect() {
    if (!this.nativeSelectRef) return;

    const options = this.selectedOptions.map(item => {
      const { selected, value, label } = item;
      return { selected, value, label };
    });

    this.nativeSelectRef.instance.multiple = this.multiple;
    this.nativeSelectRef.instance.name = this.nativeName;
    this.nativeSelectRef.instance.form = this.nativeId;
    this.nativeSelectRef.instance.options = [...options];
    this.nativeSelectRef.instance.disabled = this.disabled;
    this.nativeSelectRef.instance.changeDetectorRef.detectChanges();
  }

  inputElementSize() {
    if (this.inputElement) {
      if (this.selectedOptions.length > 0 || this.selectionType === 'counter') {
        this.renderer.setAttribute(this.inputElement.nativeElement, 'size', (this.searchValue.length + 2).toString());
      } else {
        this.renderer.removeAttribute(this.inputElement.nativeElement, 'size');
      }
    }
  }

  handleSearchKeyDown($event: KeyboardEvent) {
    if (this.searchValue.length || this.selectedOptions.length === 0) return;

    if (['Backspace', 'Delete'].includes($event.key)) {
      $event.stopPropagation();
      const last = this.selectedOptions.filter(option => !option.disabled).pop();
      this.selectOption(last, false);
    }
  }

  private selectOption(option: MultiSelectOptionComponent, selected: boolean) {
    this.multiSelectOptions.forEach(item => {
      if (item === option) {
        option.selected = selected;
      }
    });
    this.selectedOptionsUpdate();
  }

  private selectedOptionsUpdate() {
    this.selectedOptions = this.multiSelectOptions.filter((option) => !!option.selected);
  }
}

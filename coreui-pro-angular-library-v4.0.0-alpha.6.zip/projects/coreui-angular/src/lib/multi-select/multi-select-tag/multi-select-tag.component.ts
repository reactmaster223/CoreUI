import { Component, EventEmitter, HostBinding, HostListener, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { IOption } from '../multi-select.type';
import { MultiSelectService } from '../multi-select.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'c-multi-select-tag',
  templateUrl: './multi-select-tag.component.html',
  styleUrls: ['./multi-select-tag.component.scss']
})
export class MultiSelectTagComponent implements OnDestroy, OnInit {

  constructor(
    private multiSelectService: MultiSelectService
  ) { }

  private multiselectVisibleSubscription!: Subscription;
  public multiselectVisible: boolean = false;

  @Input() option?: IOption;

  @Output() remove = new EventEmitter<IOption>();

  @HostBinding('class')
  get hostClasses() {
    return {
      'form-multi-select-tag': true
    };
  }

  ngOnInit(): void {
    this.multiselectSubscribe();
  }

  ngOnDestroy(): void {
    this.multiselectSubscribe(false);
  }

  handleRemove($event: any): void {
    if (this.option) {
      this.option.selected = false;
      this.remove.emit(this.option as IOption);
    }
  }

  private multiselectSubscribe(subscribe: boolean = true) {
    if (subscribe) {
      this.multiselectVisibleSubscription =
        this.multiSelectService.multiSelectVisible$.subscribe((visible) => {
          setTimeout(() => {
            this.multiselectVisible = visible;
          })
        });
    } else {
      this.multiselectVisibleSubscription.unsubscribe();
    }
  }

}

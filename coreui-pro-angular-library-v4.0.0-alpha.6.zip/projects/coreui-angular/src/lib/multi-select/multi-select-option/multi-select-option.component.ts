import {
  AfterContentInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  HostBinding,
  HostListener,
  Input,
  OnDestroy,
  OnInit,
  Output,
  Renderer2,
  ViewChild
} from '@angular/core';
import { BooleanInput, coerceBooleanProperty } from '@angular/cdk/coercion';
import { FocusableOption, FocusMonitor, FocusOrigin } from '@angular/cdk/a11y';
import { Subscription } from 'rxjs';

import { MultiSelectService } from '../multi-select.service';

@Component({
  selector: 'c-multi-select-option',
  templateUrl: './multi-select-option.component.html',
  styleUrls: ['./multi-select-option.component.scss']
})
export class MultiSelectOptionComponent implements AfterContentInit, FocusableOption, OnInit, OnDestroy {

  constructor(
    private elementRef: ElementRef,
    private renderer: Renderer2,
    private changeDetectorRef: ChangeDetectorRef,
    private focusMonitor: FocusMonitor,
    private multiSelectService: MultiSelectService
  ) { }

  static ngAcceptInputType_disabled: BooleanInput;
  static ngAcceptInputType_selected: BooleanInput;

  @Input() optionsStyle: ('checkbox' | 'text') = 'checkbox';
  @Input() label?: string;
  @Input() value?: string;
  @Input() visible: boolean = true;
  @Output() selectedChange = new EventEmitter<boolean>();

  @ViewChild('contentDiv') content?: ElementRef;

  public hasContent = true;

  private multiselectVisibleSubscription!: Subscription;
  private dropdownVisible = false;

  @Input()
  set disabled(value: boolean) {
    this._disabled = coerceBooleanProperty(value);
  }
  get disabled() {
    return this._disabled;
  }
  private _disabled = false;

  @Input()
  set selected(value: (boolean | undefined)) {
    const newValue = coerceBooleanProperty(value);
    if (this._selected !== newValue) {
      this._selected = newValue;
      this.selectedChange.emit(newValue);
      this.multiSelectService.toggleOption(this);
    }
  }
  get selected() {
    return this._selected;
  }
  private _selected = false;

  @HostBinding('class')
  get hostClasses() {
    return {
      'form-multi-select-option': true,
      'form-multi-selected': this.selected,
      [`form-multi-select-option-with-${this.optionsStyle}`]: !!this.optionsStyle,
      disabled: this.disabled,
      'd-none': !this.visible
    };
  }

  @HostBinding('attr.tabindex')
  private get tabIndex() {
    return this.disabled ? '-1' : '0';
  }

  @HostBinding('attr.disabled')
  @HostBinding('attr.aria-disabled')
  private get ariaDisabled() {
    return this.disabled || null;
  }

  @HostBinding('attr.aria-selected')
  private get ariaSelected() {
    return this.selected;
  }

  @HostListener('keydown', ['$event'])
  onKeyDown($event: KeyboardEvent): void {
    if (['Enter', ' '].includes($event.key)) {
      $event.preventDefault();
      this.selected = this.disabled ? this.selected : !this.selected;
      this.focus('keyboard');
    }
  }

  @HostListener('click', ['$event'])
  private onClick(): void {
    this.selected = this.disabled ? this.selected : !this.selected;
    this.focus('mouse');
  }

  ngAfterContentInit(): void {
    setTimeout(() => {
      this.hasContent = !!this.content?.nativeElement.childNodes.length;
    });
    if (!this.label) {
      this.label = this.elementRef.nativeElement.innerText || this.value;
    }
    if (this.value === undefined) {
      this.value = this.elementRef.nativeElement.innerText || this.label;
    }
  }

  getLabel(): string {
    return <string>(this.label ?? this.value);
  }

  focus(origin?: FocusOrigin): void {
    if (this.dropdownVisible) {
      this.focusMonitor.focusVia(this.elementRef, origin ?? 'program', {preventScroll: false});
      this.changeDetectorRef.markForCheck();
    }
  }

  ngOnDestroy(): void {
    this.multiselectVisibleSubscription.unsubscribe();
  }

  ngOnInit(): void {
    this.multiselectVisibleSubscription = this.multiSelectService.multiSelectVisible$.subscribe(visible => {
      this.dropdownVisible = visible;
    });
  }
}

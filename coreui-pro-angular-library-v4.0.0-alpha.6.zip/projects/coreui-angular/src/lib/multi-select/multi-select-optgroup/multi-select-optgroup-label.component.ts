import { Component, HostBinding } from '@angular/core';

@Component({
  selector: 'c-multi-select-optgroup-label',
  templateUrl: './multi-select-optgroup-label.component.html',
  styleUrls: ['./multi-select-optgroup-label.component.scss']
})
export class MultiSelectOptgroupLabelComponent {

  constructor() { }

  @HostBinding('class') get hostClasses() {
    return {
      'form-multi-select-optgroup-label': true
    };
  }
}

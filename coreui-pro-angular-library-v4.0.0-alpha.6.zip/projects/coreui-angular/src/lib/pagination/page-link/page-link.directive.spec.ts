import { PageLinkDirective } from './page-link.directive';

describe('PageLinkDirective', () => {
  it('should create an instance', () => {
    const directive = new PageLinkDirective();
    expect(directive).toBeTruthy();
  });
});

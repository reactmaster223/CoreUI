import { PageItemDirective } from './page-item.directive';

describe('PageItemDirective', () => {
  it('should create an instance', () => {
    // const directive = new PageItemDirective();
    // expect(directive).toBeTruthy();
  });
});

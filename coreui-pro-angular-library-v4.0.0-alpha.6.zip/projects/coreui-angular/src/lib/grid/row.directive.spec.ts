import { RowDirective } from './row.directive';

describe('RowDirective', () => {
  it('should create an instance', () => {
    const directive = new RowDirective();
    expect(directive).toBeTruthy();
  });
});

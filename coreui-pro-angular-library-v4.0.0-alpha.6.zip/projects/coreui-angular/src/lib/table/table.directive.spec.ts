import { TableDirective } from './table.directive';

describe('TableDirective', () => {
  it('should create an instance', () => {
    // todo
    // const directive = new TableDirective();
    // expect(directive).toBeTruthy();
  });
});

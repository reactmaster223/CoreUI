import { TableActiveDirective } from './table-active.directive';

describe('TableActiveDirective', () => {
  it('should create an instance', () => {
    const directive = new TableActiveDirective();
    expect(directive).toBeTruthy();
  });
});

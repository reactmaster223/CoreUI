import { TableColorDirective } from './table-color.directive';

describe('TableColorDirective', () => {
  it('should create an instance', () => {
    const directive = new TableColorDirective();
    expect(directive).toBeTruthy();
  });
});

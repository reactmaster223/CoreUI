export { TableColorDirective } from './table-color.directive';
export { TableActiveDirective } from './table-active.directive';
export { TableDirective } from './table.directive';
export { TableModule } from './table.module';

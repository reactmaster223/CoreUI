<template>Hello World!</template>

<script>
export default {
  name: 'Dashboard',
}
</script>

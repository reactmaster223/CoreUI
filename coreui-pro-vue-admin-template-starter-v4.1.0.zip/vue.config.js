module.exports = {
  // use this option for production linking
  publicPath: process.env.NODE_ENV === 'production' ? '/vue/demo/4.0/' : '/',
}

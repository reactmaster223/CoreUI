import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Routing
import { EditorsRoutingModule } from './editors-routing.module';

@NgModule({
  imports: [
    EditorsRoutingModule
  ],
  declarations: []
})
export class EditorsModule { }

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Routing
import { AppsRoutingModule } from './apps-routing.module';

@NgModule({
  imports: [
    AppsRoutingModule
  ],
  declarations: []
})
export class AppsModule { }

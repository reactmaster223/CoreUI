import { Component } from '@angular/core';

@Component({
  templateUrl: 'invoice.component.html'
})
export class InvoiceComponent { }

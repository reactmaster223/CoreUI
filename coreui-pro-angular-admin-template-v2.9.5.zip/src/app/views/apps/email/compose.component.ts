import { Component } from '@angular/core';

@Component({
  templateUrl: 'compose.component.html'
})
export class ComposeComponent { }

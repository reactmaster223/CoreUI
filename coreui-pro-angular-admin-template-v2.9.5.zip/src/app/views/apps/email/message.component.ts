import { Component } from '@angular/core';

@Component({
  templateUrl: 'message.component.html'
})
export class MessageComponent { }

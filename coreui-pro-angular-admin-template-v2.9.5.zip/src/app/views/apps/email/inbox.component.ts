import { Component } from '@angular/core';

@Component({
  templateUrl: 'inbox.component.html'
})
export class InboxComponent { }

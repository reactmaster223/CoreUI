/**
 * --------------------------------------------------------------------------
 * CoreUI Pro Boostrap Admin Template (3.4.0): datatables.js
 * License (https://coreui.io/pro/license)
 * --------------------------------------------------------------------------
 */

$('.datatable').DataTable()
$('.datatable').attr('style', 'border-collapse: collapse !important')

/* global coreui */

/**
 * --------------------------------------------------------------------------
 * CoreUI Boostrap Admin Template (3.4.0): popovers.js
 * License (https://coreui.io/pro/license)
 * --------------------------------------------------------------------------
 */

document.querySelectorAll('[data-toggle="popover"]').forEach(element => {
  // eslint-disable-next-line no-new
  new coreui.Popover(element)
})

// import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
// import { NoopAnimationsModule } from '@angular/platform-browser/animations';
//
// import { AppToastComponent } from './toast.component';
//
// describe('ToastComponent', () => {
//   let component: AppToastComponent;
//   let fixture: ComponentFixture<AppToastComponent>;
//
//   beforeEach(waitForAsync(() => {
//     TestBed.configureTestingModule({
//       declarations: [ AppToastComponent ],
//       imports: [NoopAnimationsModule]
//     })
//     .compileComponents();
//   }));
//
//   beforeEach(() => {
//     fixture = TestBed.createComponent(AppToastComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });
//
//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });

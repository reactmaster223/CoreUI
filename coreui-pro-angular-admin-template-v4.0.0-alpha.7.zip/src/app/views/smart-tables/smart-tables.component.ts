import { Component } from '@angular/core';

@Component({
  selector: 'app-smart-tables',
  templateUrl: './smart-tables.component.html',
  styleUrls: ['./smart-tables.component.scss']
})
export class SmartTablesComponent {
}

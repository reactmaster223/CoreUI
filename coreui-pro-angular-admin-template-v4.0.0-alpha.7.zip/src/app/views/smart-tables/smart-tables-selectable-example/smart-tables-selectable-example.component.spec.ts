import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SmartTablesSelectableExampleComponent } from './smart-tables-selectable-example.component';

describe('SmartTablesSelectableExampleComponent', () => {
  let component: SmartTablesSelectableExampleComponent;
  let fixture: ComponentFixture<SmartTablesSelectableExampleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SmartTablesSelectableExampleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SmartTablesSelectableExampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

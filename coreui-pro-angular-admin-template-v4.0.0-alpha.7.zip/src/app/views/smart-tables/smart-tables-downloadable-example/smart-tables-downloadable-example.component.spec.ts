import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SmartTablesDownloadableExampleComponent } from './smart-tables-downloadable-example.component';

describe('SmartTablesDownloadableExampleComponent', () => {
  let component: SmartTablesDownloadableExampleComponent;
  let fixture: ComponentFixture<SmartTablesDownloadableExampleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SmartTablesDownloadableExampleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SmartTablesDownloadableExampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

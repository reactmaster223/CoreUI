<template>
  <div>Hello World</div>
</template>

<script>
export default {
  name: 'AppDashboard',
  components: {},
  // setup() {},
}
</script>
